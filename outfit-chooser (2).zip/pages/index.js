
import React, { useState } from "react";

export default function OutfitChooser() {
  const [wardrobe, setWardrobe] = useState([]);
  const [suggestion, setSuggestion] = useState(null);

  const handleUpload = (e) => {
    const files = Array.from(e.target.files);
    const items = files.map((file) => URL.createObjectURL(file));
    setWardrobe([...wardrobe, ...items]);
  };

  const generateOutfit = () => {
    if (wardrobe.length < 2) return;
    const shuffled = [...wardrobe].sort(() => 0.5 - Math.random());
    setSuggestion(shuffled.slice(0, 3));
  };

  return (
    <div style={{ padding: '2rem', backgroundColor: '#f9f6f1', minHeight: '100vh', fontFamily: 'serif', color: '#2c2c2c' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', textAlign: 'center' }}>Curated Wardrobe</h1>
      <input
        type="file"
        multiple
        accept="image/*"
        onChange={handleUpload}
        style={{ margin: '1rem 0', display: 'block', width: '100%' }}
      />
      <button onClick={generateOutfit} style={{ padding: '0.75rem', backgroundColor: '#5e4b3c', color: 'white', border: 'none', width: '100%' }}>
        Select My Look
      </button>

      {suggestion && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '1rem', marginTop: '2rem' }}>
          {suggestion.map((item, idx) => (
            <div key={idx} style={{ backgroundColor: 'white', borderRadius: '1rem', boxShadow: '0 0 10px rgba(0,0,0,0.1)', padding: '1rem' }}>
              <img src={item} alt={`Clothing item ${idx}`} style={{ borderRadius: '0.75rem', width: '100%' }} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
